Download dataset and save all sequences at here.
